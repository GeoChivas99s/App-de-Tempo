import React, { Component } from 'react';


class App extends React.Component{

render(){

return (
<div><h1>  
   Hello World
  </h1>
  <div>
    <span> Olá mundo </span>
  </div>
  </div> 
)
};
}

export default App;
